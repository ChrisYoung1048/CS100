#ifndef PARSE_ADVANCED_HPP
#define PARSE_ADVANCED_HPP

#include "parse.hpp"

class ParseAdvanced : public Parse {
	public:
		vector<char> parse(int i);
};

#endif // PARSE_ADVANCED_HPP
