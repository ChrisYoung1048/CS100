#ifndef PARSE_NOVICE_HPP
#define PARSE_NOVICE_HPP

#include "parse.hpp"

class ParseNovice : public Parse {
	public:
		vector<char> parse(int i);
};

#endif // PARSE_NOVICE_HPP
