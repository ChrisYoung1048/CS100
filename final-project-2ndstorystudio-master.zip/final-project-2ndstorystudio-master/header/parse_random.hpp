#ifndef PARSE_RANDOM_HPP
#define PARSE_RANDOM_HPP

#include "parse.hpp"

class ParseRandom : public Parse {
	public:
		vector<char> parse(int i);
};

#endif // PARSE_RANDOM_HPP
