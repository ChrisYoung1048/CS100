#ifndef PARSE_INTERMEDIATE_HPP
#define PARSE_INTERMEDIATE_HPP

#include "parse.hpp"

class ParseIntermediate : public Parse {
	public:
		vector<char> parse(int i);
};

#endif // PARSE_INTERMEDIATE_HPP
