#ifndef __VECTORCONTAINER_TEST_HPP__
#define __VECTORCONTAINER_TEST_HPP__

#include "gtest/gtest.h"
#include "VectorContainer.hpp"
#include "base.hpp"
#include "bubbleSort.hpp"
#include "SelectionSort.hpp"
TEST(v_add_element, simpleOperands) {
	VectorContainer v;
	Base* seven = new Op(7);
	Base* three = new Op(3);
	v.add_element(seven);
        v.add_element(three);

	testing::internal::CaptureStdout();
        v.print();
        std::string output = testing::internal::GetCapturedStdout();

	EXPECT_EQ(output, "73");
}

TEST(v_add_element, combinationOps) {
	VectorContainer v;
	Base* seven = new Op(7);
	Base* three = new Op(3);
	Base* mult = new Mult(seven, three);
	v.add_element(seven);
	v.add_element(three);
	v.add_element(mult);

	testing::internal::CaptureStdout();
	v.print();
	std::string output = testing::internal::GetCapturedStdout();

	EXPECT_EQ(output, "737 * 3");
}

TEST(v_swap, simpleOperandsMiddle) {
	VectorContainer v;
        Base* seven = new Op(7);
        Base* three = new Op(3);

	v.add_element(seven);
        v.add_element(three);
   	v.add_element(seven);
	v.add_element(seven);
	v.swap(1,2);

	testing::internal::CaptureStdout();
        v.print();
        std::string output = testing::internal::GetCapturedStdout();

	EXPECT_EQ(output, "7737");
}

TEST(v_swap, simpleOperandsEdge) {
        VectorContainer v;
        Base* seven = new Op(7);
        Base* three = new Op(3);

        v.add_element(three);
        v.add_element(seven);
        v.add_element(seven);
        v.add_element(seven);
        v.swap(0,3);

        testing::internal::CaptureStdout();
        v.print();
        std::string output = testing::internal::GetCapturedStdout();

        EXPECT_EQ(output, "7773");
}

TEST(v_at, simpleOperands) {
	VectorContainer v;
        Base* seven = new Op(7);
        Base* three = new Op(3);

	v.add_element(seven);
	v.add_element(seven);
	v.add_element(seven);
	v.add_element(three);
	v.add_element(seven);

	EXPECT_EQ(v.at(3)->stringify(), "3");
}

TEST(v_at, opTree) {
        VectorContainer v;
        Base* seven = new Op(7);
        Base* three = new Op(3);
	Mult* mult = new Mult(seven, three);
	Div* div = new Div(mult, three);

        v.add_element(mult);
        v.add_element(div);
        v.add_element(mult);

        EXPECT_EQ(v.at(1)->stringify(), "7 * 3 / 3" );
}

TEST(v_size, Empty) {
        VectorContainer v;
        EXPECT_EQ(v.size(), 0);
}

TEST(v_size, NonEmpty) {
	VectorContainer v;
        Base* seven = new Op(7);
	v.add_element(seven);
	v.add_element(seven);
	v.add_element(seven);

	EXPECT_EQ(v.size(), 3);	
}

TEST(v_sort, NullPtr) {
        VectorContainer v;
        testing::internal::CaptureStdout();
        v.sort();
        std::string output = testing::internal::GetCapturedStdout();
        EXPECT_EQ(output, "Caught exception");
}

TEST(v_sort, EmptySelectionSort) {
        VectorContainer v(new SelectionSort());
	v.sort();

	testing::internal::CaptureStdout();
        v.print();
        std::string output = testing::internal::GetCapturedStdout();

        EXPECT_EQ(output, "");
}

TEST(v_sort, SelectionSort) {
	VectorContainer v(new SelectionSort());
 	Base* seven = new Op(7);
        Base* three = new Op(3);
	Base* four = new Op(4);
	v.add_element(seven);
	v.add_element(three);
	v.add_element(four);
 	v.sort();

	testing::internal::CaptureStdout();
        v.print();
        std::string output = testing::internal::GetCapturedStdout();

	EXPECT_EQ(output, "347");
}

TEST(v_sort, EmptyBubbleSort) {
        VectorContainer v(new BubbleSort());
        v.sort();

        testing::internal::CaptureStdout();
        v.print();
        std::string output = testing::internal::GetCapturedStdout();

        EXPECT_EQ(output, "");
}

TEST(V_sort, SelectionSort) {
        VectorContainer v(new BubbleSort());
        Base* seven = new Op(7);
        Base* three = new Op(3);
        Base* four = new Op(4);
        v.add_element(seven);
        v.add_element(three);
        v.add_element(four);
	v.sort();
        testing::internal::CaptureStdout();
        v.print();
        std::string output = testing::internal::GetCapturedStdout();

        EXPECT_EQ(output, "347");
}


#endif
