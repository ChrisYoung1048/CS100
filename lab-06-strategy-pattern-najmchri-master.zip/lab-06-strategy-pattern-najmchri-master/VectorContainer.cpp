#include "VectorContainer.hpp"
#include <iostream>
#include <algorithm>

VectorContainer::VectorContainer() : Container() {};
VectorContainer::VectorContainer(Sort* function) : Container(function){};

void VectorContainer::set_sort_function(Sort* sort_function) {
	this->sort_function = sort_function;
}

void VectorContainer::add_element(Base* element) {
	baseVector.push_back(element);
}

void VectorContainer::print() {
	std::vector<Base*>::iterator it;
        for (it = baseVector.begin(); it!= baseVector.end(); ++it) {
        	std::cout <<(*it)->stringify();
        }
}

void VectorContainer::sort() {
      
        try {
                if(sort_function == nullptr) {
                        throw 1;
                }
                sort_function->sort(this);
        } catch (int e) {
                std::cout << "Caught exception";
        }
 
}

void VectorContainer::swap(int i, int j) {
	std::vector<Base*>::iterator it1 = baseVector.begin();
	std::vector<Base*>::iterator it2 = baseVector.begin();
	for (int k = 0; k < i; ++k) { it1++; }
	for (int k = 0; k < j; ++k) { it2++; }
	std::iter_swap(it1, it2);	
}

Base* VectorContainer::at(int i) {
	std::vector<Base*>::iterator it = baseVector.begin();
	for (int k = 0; k < i; ++k) { it++; }
	return *it;
}

int VectorContainer::size() { return baseVector.size(); }
