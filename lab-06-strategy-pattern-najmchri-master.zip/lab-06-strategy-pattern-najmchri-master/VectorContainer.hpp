#ifndef __VECTORCONTAINER_HPP__
#define __VECTORCONTAINER_HPP__

#include "sort.hpp"
#include "base.hpp"
#include "container.hpp"

#include <vector>
#include <iterator>

class VectorContainer : public Container {
	protected:
		std::vector<Base*> baseVector;
	public:
		VectorContainer();
		VectorContainer(Sort* function);
		void set_sort_function(Sort* sort_function);
		void add_element(Base* element);
		void print();
		void sort();
		void swap(int i, int j);
		Base* at(int i);
		int size();
};

#endif
