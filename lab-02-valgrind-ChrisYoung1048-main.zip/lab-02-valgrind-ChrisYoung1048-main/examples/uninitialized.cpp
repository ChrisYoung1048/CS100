#include <iostream>
using namespace std;

int main() {
    int x = 10;
    cout << x << endl;

    return 0;
}
